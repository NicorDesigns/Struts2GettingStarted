DROP DATABASE IF EXISTS insurance_admin;
CREATE DATABASE insurance_admin;