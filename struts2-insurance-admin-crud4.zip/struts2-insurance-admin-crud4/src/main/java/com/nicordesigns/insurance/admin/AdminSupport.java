package com.nicordesigns.insurance.admin;

import com.opensymphony.xwork2.ActionSupport;

/**
 * Base Action class for the Tutorial package.
 */
public class AdminSupport extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8613119747485974602L;
}
