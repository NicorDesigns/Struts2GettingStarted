package com.nicordesigns.insurance.admin.utils;

public interface Struts2InsuranceAdminConstants {
	
	public static final String ADMINISTRATOR = "Administrator";

}
