package com.nicordesigns.insurance.admin.utils;

public interface AdministratorAware {
	
	public void setAdministrator(Administrator administrator);

}
