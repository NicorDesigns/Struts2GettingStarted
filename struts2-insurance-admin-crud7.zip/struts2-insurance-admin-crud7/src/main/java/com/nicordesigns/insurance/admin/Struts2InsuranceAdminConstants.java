package com.nicordesigns.insurance.admin;

public interface Struts2InsuranceAdminConstants {
	
	public static final String ADMINISTRATOR = "Administrator";

}