CREATE USER 'insurance_app'@'localhost' IDENTIFIED BY 'insurance_app';

GRANT ALL PRIVILEGES ON *.* TO 'insurance_app'@'localhost';

