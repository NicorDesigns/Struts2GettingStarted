package com.nicordesigns.insurance.admin.service;

import java.util.List;
import com.nicordesigns.insurance.admin.model.Agent;

public interface AgentServiceInterface {
	
	List<Agent> getAllAgents();

}
